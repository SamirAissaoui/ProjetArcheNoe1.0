-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le :  mar. 09 juil. 2019 à 14:48
-- Version du serveur :  10.3.16-MariaDB
-- Version de PHP :  7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `filrouge`
--

-- --------------------------------------------------------

--
-- Structure de la table `classification`
--

CREATE TABLE `classification` (
  `id` int(11) NOT NULL,
  `min_desc` text NOT NULL,
  `nom` text NOT NULL,
  `regne` text NOT NULL,
  `embranchement` text NOT NULL,
  `classe` text NOT NULL,
  `ordre` text NOT NULL,
  `famille` text NOT NULL,
  `genre` text NOT NULL,
  `espece` text NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `classification`
--

INSERT INTO `classification` (`id`, `min_desc`, `nom`, `regne`, `embranchement`, `classe`, `ordre`, `famille`, `genre`, `espece`, `img`) VALUES
(1, 'La baleine bleue ou rorqual bleu est le plus gros animal ayant jamais existé sur Terre devant le rorqual commun avec lequel elle peut s\'hybrider. Son corps est gris-bleu sur la face supérieure et blanc sur la face inférieure. Ses nageoires sont petites par rapport à son corps. Comme toutes les baleines, elle ne possède pas de dents mais des fanons servant de filtre.', 'Baleine Bleue', 'Animal', 'Chordé vertébré', 'Mammifère placentaire ', 'Cétartiodactyle cétacé odontocète', 'Balénoptéridé', 'Balaenoptera', 'musculus', 'https://images.ladepeche.fr/api/v1/images/view/5c2e902f8fe56f62f029399b/large/image.jpg'),
(2, 'Le dromadaire est un animal très proche du chameau avec lequel il est interfécond et peut donner un turkoman. Il possède un pelage de couleur sable à brun fauve, ainsi qu\'un long cou, et de longues et fines pattes. Il est particulièrement reconnaissable par l\'unique bosse de graisse qu\'il porte sur le dos par opposition avec le chameau qui en porte deux.', 'Dromadaire', 'Animal', 'Chordé vertébré', 'Mammifère placentaire ', 'Cétartiodactyle tylopode', 'Camélidé', 'Camelus', 'dromedarius', 'http://www.jaitoutcompris.com/img/encyclo/dromadaire.jpg'),
(3, 'Le singe hibou ou douroucouli commun ou encore singe de nuit est un petit singe au pelage généralement gris-brun. La face ventrale est plus clair et présente des teintes oranges pâles. Le visage est gris et blanc. Sa longue queue se fonce vers son extrémité.\r\n', 'Singe Hibou', 'Animal', 'Chordé vertébré', 'Mammifère placentaire ', 'Primate haplorhinien simiforme ', 'Catarhinien cercopithécidé cercopithéciné', 'Aotus', 'trivirgatus', 'https://img.maxisciences.com/article/international/chez-les-singes-hibou-c-est-le-pere-biologique-qui-s-occupe-principalement-de-l-education-de-son-petit-chaque-annee-il-s-accouple-avec-la-meme-femelle_0a82b5d56894cc1ee17c1b92a38074ceeb623d55.jpg'),
(4, 'Le glouton ou carcajou est l’un des carnivores le plus mal connu. Il ressemble à un blaireau et à un ours ( les amateurs le confondent d\'ailleurs très souvent avec un ourson ). Son pelage est de couleur chocolat et est dense et ne retient pas l\'eau, ce qui lui permet de résister aux grands froids. Le corps et les pattes sont larges, la tête et les oreilles sont rondes.', 'Glouton', 'Animal', 'Chordé vertébré', 'Mammifère placentaire', 'Carnivore caniforme', 'Mustélidé mustéliné', 'Gulo', 'gulo', 'http://img.over-blog-kiwi.com/1020x765/1/17/73/72/20161104/ob_6fae51_blog-dehondt-desmets-2373-border.jpg'),
(5, 'L\'Aigle royal est un grand rapace brun foncé. Son pelage est légèrement doré au niveau des ailes et du coup. Avec son envergure de plus de 2m, c\'est l\'un des plus grands rapaces du monde. Son bec crochu, ses serres puissantes et acérées lui servent à attraper ses proies et à les dépecer.', 'Aigle Royal', 'Animal', 'Chordé', 'Oiseau', 'Accipitriformes', 'Accipitridé', 'Aquila', 'chrysaetos', 'http://www.mercantour-parcnational.fr/sites/mercantour.eu/files/thumbnails/image/02831_pnm.jpg');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `classification`
--
ALTER TABLE `classification`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `classification`
--
ALTER TABLE `classification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
