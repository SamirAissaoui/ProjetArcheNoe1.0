<!DOCTYPE html>
<html lang="en">
<?php
  session_start() ;
  echo $_SESSION['user']; 
?>
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Ajouter un nouvel animal</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/heroic-features.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">L'Arche de Noé</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="gestion.php">Retourner sur la page précédente 
              <span class="sr-only">(current)</span>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">

    <!-- Jumbotron Header -->
    <header class="jumbotron my-4">
    <h1 align="center"> Ajout d'un nouvel animal </h1><br><br><br>


<form method="POST" action="verifclass.php">
 
    <li>Le nom :  <br><input name="nom" id="nom" type="text" required/> <br><br></li>

    <li>Description : <br><input name="min_desc" id="min_desc" type="text" required/> <br><br></li>

    <li>Le regne :  <br><input name="regne" id="regne" type="text" required/> <br><br></li>

    <li>L'embranchement : <br><input name="embranchement" id="embranchement" type="text" required/> <br><br></li>

    <li>La classe : <br><input name="classe" id="classe" type="text" required/> <br><br></li>
  
    <li>L'ordre : <br><input name="ordre" id="ordre" type="text" required/> <br><br></li>

    <li>La famille : <br><input name="famille" id="famille" type="text" required/> <br><br></li>

    <li>Le genre : <br><input name="genre" id="genre" type="text" required/> <br><br></li>

    <li>L'espece : <br><input name="espece" id="espece" type="text" required/> <br><br></li>

    <li>Lien URL d'une photo de l'animal concerné :  <br><input name="img" id="img" type="text" required/> <br><br></li>

    <h4 align="center"><input type="submit" value="Créer"/></h4>

</form>


    </header>

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; L'Arche de Noé 2019</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>