<!DOCTYPE html>
<html lang="en">


<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Classification</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="css/full-width-pics.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="\projetfilrouge/accueil.php?id='$_SESSION['id']'">Retour sur le site</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">

      </div>
    </div>
  </nav>

  <?php 
  $leid = $_GET['id'] ; 
  
  try
  {
      // On se connecte à MySQL
      $bdd = new PDO('mysql:host=localhost;dbname=filrouge;charset=utf8', 'root', '');
  }
  catch(Exception $e)
  {
      // En cas d'erreur, on affiche un message et on arrête tout
          die('Erreur : '.$e->getMessage());
  }
  
  $reponse = $bdd->query('SELECT * FROM classification WHERE id='.$leid.'');
  $donnees = $reponse->fetch(); 

  ?>
  <!-- Header - set the background image for the header in the line below -->
  <header class="py-5 bg-image-full" style="background-image: url('<?php echo($donnees['img']) ; ?>');">
    <img class="img-fluid d-block mx-auto" width="450px" src="<?php echo($donnees['img']) ; ?>" alt="">
  </header>
  <!-- Content section -->
  <section class="py-5">
    <div class="container">
      <h1><?php echo($donnees['nom']) ; ?></h1>
    </div>
  </section>

  
    <!-- Put anything you want here! There is just a spacer below for demo purposes! -->
<div style="text-align: center"><img width=450px src="<?php echo($donnees['img']) ; ?>"/></div></div>
  </section><br><br>


  <!-- Content section -->
  <section class="py-5">
    <div class="container">
      <p><?php echo($donnees['min_desc']) ; ?></p>
      <br><br>
    <li><B>Regne :</B> <?php echo($donnees['regne']) ; ?></li>
    <li><B>Embranchement :</B> <?php echo($donnees['embranchement']) ; ?></li>
    <li><B>Classe :</B> <?php echo($donnees['classe']) ; ?></li>
    <li><B>Ordre :</B> <?php echo($donnees['ordre']) ; ?></li>
    <li><B>Famille :</B> <?php echo($donnees['famille']) ; ?></li>
    <li><B>Genre :</B> <?php echo($donnees['genre']) ; ?></li>
    <li><B>Espece :</B> <?php echo($donnees['espece']) ; ?></li>

    </div>

  </section>


  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Association l'Arche de Noé 2019</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
