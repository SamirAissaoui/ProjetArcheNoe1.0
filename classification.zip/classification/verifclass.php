<?php

$min_desc = $_POST['min_desc'];
$nom = $_POST['nom']; 
$regne = $_POST['regne']; 
$embranchement = $_POST['embranchement']; 
$classe = $_POST['classe'];
$ordre = $_POST['ordre']; 
$img = $_POST['img'];
$famille = $_POST['famille'];
$genre = $_POST['genre'];
$espece = $_POST['espece'];


try
{
	//se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=filrouge;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}
$bdd->exec("INSERT INTO classification VALUES (default,'$min_desc','$nom','$regne','$embranchement','$classe','$ordre','$img','$famille','$genre','$espece')");
	header('Location: \projetfilrouge\accueil.php');

?>